__version__ = '0.1.0'
from online_beast.main import app